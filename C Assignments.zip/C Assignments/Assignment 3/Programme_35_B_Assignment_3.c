/*Programme to print series using nested loop(B)*/
#include <stdio.h>
void main()
{
    for(int i=1;i<=3;i++)
    {
        for(int j=1;j<=i;j++)
        printf("%d %d\n",i,j);
    }
}
