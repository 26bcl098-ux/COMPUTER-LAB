/* Programme to divide two numbers*/
#include <stdio.h>
void main()
{
    int num1,num2;
    printf("Enter a number:");
    scanf("%d",&num1);
    printf("Enter another number:");
    scanf("%d",&num2);
    printf("%d / %d = %f\n",num1,num2,num1/(float)num2);
}